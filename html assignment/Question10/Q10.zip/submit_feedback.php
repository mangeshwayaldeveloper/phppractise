<?php

use PHPMailer\PHPMailer\PHPMailer;

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

$mail = new PHPMailer;


$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
$mail->Username = 'maheshmoholkar171@gmail.com';
$mail->Password = 'aoyaywdrjqseejld';
$mail->SMTPSecure = 'tls';
$mail->Port = 587;

$problem = $_POST['problem'];
$username = $_POST['username'];
$email = $_POST['email'];
$location = $_POST['location'];
$phone = $_POST['phone'];
$description = $_POST['description'];
$notification = isset($_POST['notification']) ? "Yes" : "No";

$subject = "Sports Website Feedback - Problem: $problem";

$message = "Type of Problem: $problem\n";
$message .= "Username: $username\n";
$message .= "Email: $email\n";
$message .= "Location: $location\n";
$message .= "Phone: $phone\n";
$message .= "Description of the Problem: $description\n";
$message .= "Notification of Problem Solved: $notification\n";

$to = $_POST['email'];

$mail->setFrom('maheshmoholkar171@gmail.com', 'Mahesh Moholkar');
$mail->addAddress($to, 'Hello');

// Email content
$mail->Subject = $subject;
$mail->Body = $message;

if ($mail->send()) {
    echo "Email sent successfully.";
} else {
    echo "Email sending failed. Error: " . $mail->ErrorInfo;
}
?>